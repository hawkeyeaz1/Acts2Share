<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'purel9_acts2');
define('DB_PASSWORD', 'redacted');
define('DB_DATABASE', 'purel9_acts2db');
?>
